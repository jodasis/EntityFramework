﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExamenEntityFramework.Modelos;

namespace ExamenEntityFramework
{
    public partial class Form1 : Form
    {
        String cargo = "";
        List<DetalleProducto> detalleProductosList = new List<DetalleProducto>();

        public Form1()
        {
            InitializeComponent();
            detalleProductosList = new List<DetalleProducto>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ddbb = new GestionEmpresaXDB();
            /*var estudiantes = ddbb.Estudiantes.ToList();
            string texto = "";
            foreach (var est in estudiantes)
            {
                texto += $"{est.ci}: {est.apellido} {est.nombre} {est.email}\n";
            }*/
            /*richTextBox1.Text = texto;

            dataGridView1.DataSource = estudiantes;
            label.Text = "jodasis";*/
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            var ddbb = new GestionEmpresaXDB();
            Farmaceutico farmaceutico = ddbb.Farmaceutico.SingleOrDefault(c => c.ci == textBox1.Text && c.contrasena == textBox2.Text);
            if (farmaceutico != null)
            {
                this.cargo = farmaceutico.cargo;
                label3.Text = "Acceso correcto: " + this.cargo;
            } else
            {
                label3.Text = "Error: usuario o contraseña es incorrecto, intente de nuevo.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
                var ddbb = new GestionEmpresaXDB();
                Cliente cliente = ddbb.Cliente.SingleOrDefault(c => c.nit == textBox3.Text);
                if (cliente == null)
                {
                    var newCliente = new Cliente()
                    {
                        nit = textBox3.Text, // mi va id_m_c pues es IDENTITY(1,1) en la tabla
                        nombreCliente = textBox4.Text,
                        apellidoCliente = textBox5.Text
                    };
                    ddbb.Cliente.Add(newCliente);
                    ddbb.SaveChanges();
                }
                var medicamentos = ddbb.Medicamento
                    .Where(met => met.codMedic == textBox6.Text).ToList();
                if (medicamentos != null)
                {
                    foreach (var medicamento in medicamentos)
                    {
                        DetalleProducto detalleProducto = new DetalleProducto();
                        detalleProducto.codMedic = medicamento.codMedic;
                        detalleProducto.precio = medicamento.precio * int.Parse(textBox7.Text);
                        detalleProductosList.Add(detalleProducto);
                    }
                }
                textBox6.Text = "";
                textBox7.Text = "";
                dataGridView1.DataSource = detalleProductosList;
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
