﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ExamenEntityFramework.Modelos
{
    public class GestionEmpresaXDB : DbContext
    {
        public DbSet<Cliente> Cliente { get; set; }
        public DbSet<Farmaceutico> Farmaceutico { get; set; }
        public DbSet<Medicamento> Medicamento { get; set; }
        public DbSet<DetalleMed> DetalleMed { get; set; }
        public DbSet<Factura> Factura { get; set; }
        public DbSet<DetalleVenta> DetalleVenta { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder opBuilder)
        {
            if (!opBuilder.IsConfigured)
            {
                var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appconfig.json");
                var config = builder.Build();
                opBuilder.UseLazyLoadingProxies().UseSqlServer(config["ConnectionStrings:miConexion"]);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DetalleVenta>(entidad =>
            {
                entidad.HasOne(mc => mc.factura).WithMany(dme => dme.detalleVentas)
                .HasForeignKey(mc => mc.numFactura).HasConstraintName("fk_detalleVentas_factura");
            });
            modelBuilder.Entity<DetalleVenta>(entidad =>
            {
                entidad.HasOne(mc => mc.medicamento).WithMany(dme => dme.detalleVentas)
                .HasForeignKey(mc => mc.codMedic).HasConstraintName("fk_detalleVentas_medicamento");
            });
            modelBuilder.Entity<DetalleMed>(entidad =>
            {
                entidad.HasOne(dv => dv.medicamento).WithMany(dme => dme.detalleMeds)
                .HasForeignKey(dv => dv.codDetalle).HasConstraintName("fk_detalleMeds_medicamento");
            });
        }
    }
}
