﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("Farmaceutico")]
    public class Farmaceutico
    {
        [Key]
        public string ci { get; set; }
        public string nombreFarm { get; set; }
        public string apellidoFarm { get; set; }
        public string contrasena { get; set; }
        public string cargo { get; set; }
    }
}
