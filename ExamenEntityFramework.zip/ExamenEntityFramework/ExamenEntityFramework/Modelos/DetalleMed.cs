﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("DetalleMed")]
    public class DetalleMed
    {
        [Key]
        public string codDetalle { get; set; }
        public string nombreMedic { get; set; }
        public string descripcion { get; set; }
        public virtual Medicamento medicamento { get; set; }
    }
}
