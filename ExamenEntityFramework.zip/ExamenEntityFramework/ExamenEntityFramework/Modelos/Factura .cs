﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("Factura")]
    public class Factura
    {
        [Key]
        public int numFactura { get; set; }
        public DateTime fecha { get; set; }
        public string ci { get; set; }
        public string nit { get; set; }
        public virtual ICollection<DetalleVenta> detalleVentas { get; set; }
        public Factura()
        {
            detalleVentas = new HashSet<DetalleVenta>();
        }
    }
}
