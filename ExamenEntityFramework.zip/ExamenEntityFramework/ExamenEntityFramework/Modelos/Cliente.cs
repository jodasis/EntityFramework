﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("Cliente")]
    public class Cliente
    {
        [Key]
        public string nit { get; set; }
        public string nombreCliente { get; set; }
        public string apellidoCliente { get; set; }
    }
}
