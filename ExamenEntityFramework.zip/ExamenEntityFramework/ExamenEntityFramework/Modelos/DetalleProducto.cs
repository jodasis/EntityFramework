﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    public class DetalleProducto
    {
        public string codMedic { get; set; }
        public int precio { get; set; }
        public string nombreMedic { get; set; }
        public string descripcion { get; set; }

    }
}
