﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("Medicamento")]
    public class Medicamento
    {
        [Key]
        public string codMedic { get; set; }
        public DateTime fechaExp { get; set; }
        public string codDetalleMed { get; set; }
        public int precio { get; set; }
        public virtual ICollection<DetalleMed> detalleMeds { get; set; }
        public virtual ICollection<DetalleVenta> detalleVentas { get; set; }
        public Medicamento()
        {
            detalleMeds = new HashSet<DetalleMed>();
            detalleVentas = new HashSet<DetalleVenta>();
        }
    }
}
