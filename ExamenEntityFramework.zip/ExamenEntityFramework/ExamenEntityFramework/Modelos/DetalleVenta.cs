﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ExamenEntityFramework.Modelos
{
    [Table("DetalleVenta")]
    public class DetalleVenta
    {
        [Key]
        public int numFactura { get; set; }
        public string codMedic { get; set; }
        public int cantidad { get; set; }
        public virtual Factura factura { get; set; }
        public virtual Medicamento medicamento { get; set; }
    }
}
